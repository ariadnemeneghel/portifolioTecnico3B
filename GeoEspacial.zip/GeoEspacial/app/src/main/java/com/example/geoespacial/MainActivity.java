package com.example.geoespacial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton At, Aba, AbV, NL, Af, V,  H;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        At = findViewById(R.id.At);
        Aba = findViewById(R.id.Aba);
        AbV = findViewById(R.id.AbV);
        NL = findViewById(R.id.NL);
        Af = findViewById(R.id.Af);
        V = findViewById(R.id.V);
        H = findViewById(R.id.H);
    }
    public void click(View v){
        Intent i = new Intent(this, TelaCalculo.class);
        if(At.isChecked()){
            TelaCalculo.formula = 1;
            startActivity(i);
        }
        else if (Aba.isChecked()){
            TelaCalculo.formula = 2;
            startActivity(i);
        }
        else if (AbV.isChecked()){
            TelaCalculo.formula = 6 ;
            startActivity(i);
        }
        else if (NL.isChecked()){
            TelaCalculo.formula = 5;
            startActivity(i);
        }
        else if (Af.isChecked()){
            TelaCalculo.formula = 4;
            startActivity(i);
        }
        else if (V.isChecked()){
            TelaCalculo.formula = 3;
            startActivity(i);
        }
        else if (H.isChecked()){
            TelaCalculo.formula = 7;
            startActivity(i);
        }
        else{
            Toast.makeText(this, "Você precisa selecionar uma opção", Toast.LENGTH_LONG).show();
        }
    }
}

